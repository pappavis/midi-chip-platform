# GOVERNANCE

See:
- `governance/governance_model.md`
- `governance/approval_gates.md`
- `governance/roles_and_responsibilities.md`
- `governance/artifact_policy.md`
- `governance/handoff_policy.md`
