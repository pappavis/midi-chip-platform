# ROADMAP

## Current focus
- Establish KasperAIBouer governance core
- Complete taxidermy_mvp discovery and scope lock

## Later candidate modules
- Diesel rebate
- WhatsApp pocket accountant
- CRM core abstraction
- Other vertical business modules

## Rule
Later modules must not silently enter current MVP scope.
