# TEMPLATE — RELEASE NOTES

## Release
## Scope
## Included artefacts
## Not included
## Known risks
## Validation status
## Recommended next action
