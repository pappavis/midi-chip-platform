# CHANGELOG

## v0.1
### Added
- Initial `KasperAIBouer` prompt pack
- Governance inheritance first-run protocol
- OpenClaw bootstrap prompt
- Master prompt
- 9 agent prompts
- Scrum Master skill spec
- Governance docs and templates
- `taxidermy_mvp` module scaffold

### Notes
- This package is intended as a governance and scaffolding layer.
- Application implementation should happen only after source synthesis, MVP scope lock and risk review.
