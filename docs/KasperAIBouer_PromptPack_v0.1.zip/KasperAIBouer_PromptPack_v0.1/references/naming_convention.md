# NAMING CONVENTION

Gebruik konsekwente, tydgedrewe en beskrywende naming.

## Formaat
`YYYY-MM-DD_<source>_<topic>_<version>.<ext>`

## Voorbeelde
- `2026-04-07_whatsapp_kasper_taxidermy_call_v1.md`
- `2026-04-07_voice_note_kasper_process_explainer_v1.md`
- `2026-04-07_prd_taxidermy_requirements_v1.docx`
- `2026-04-07_inheritance_sn76489builder_masterprompt_v1.md`

## Reëls
- gebruik kleinletters waar moontlik
- gebruik underscores
- geen vae name soos `notes_final_new2.md`
- as taal relevant is, voeg dit by bv. `_af` of `_en`
