# ZIP CONTENT MAP

## Root
- `README.md`
- `INSTALL.md`
- `ZIP_CONTENT_MAP.md`
- `CHANGELOG.md`

## Agents
- `agents/master.md`
- `agents/intake_analyst.md`
- `agents/business_analyst.md`
- `agents/functional_designer.md`
- `agents/infrastructure_architect.md`
- `agents/scrum_master.md`
- `agents/devils_advocate.md`
- `agents/qa.md`
- `agents/release_manager.md`

## Skills
- `skills/scrum_master_skill.md`

## Prompts
### Master
- `prompts/master/kasperaibouer_master.md`

### Bootstrap
- `prompts/bootstrap/first_run_governance_intake.md`
- `prompts/bootstrap/openclaw_bootstrap.md`

### Utilities
- `prompts/utilities/module_kickoff.md`
- `prompts/utilities/summary_generation.md`
- `prompts/utilities/review_cycle.md`

## Governance
- `governance/governance_model.md`
- `governance/approval_gates.md`
- `governance/roles_and_responsibilities.md`
- `governance/artifact_policy.md`
- `governance/handoff_policy.md`

## Templates
- `templates/project_charter_template.md`
- `templates/business_case_template.md`
- `templates/functional_spec_template.md`
- `templates/technical_spec_template.md`
- `templates/data_model_template.md`
- `templates/risk_register_template.md`
- `templates/assumptions_register_template.md`
- `templates/backlog_template.md`
- `templates/qa_checklist_template.md`
- `templates/release_template.md`

## Module scaffold
- `modules/taxidermy_mvp/README.md`
- `modules/taxidermy_mvp/BUSINESS_CASE.md`
- `modules/taxidermy_mvp/FUNCTIONAL_SPEC.md`
- `modules/taxidermy_mvp/DATA_MODEL.md`
- `modules/taxidermy_mvp/RISK_REGISTER.md`
- `modules/taxidermy_mvp/BACKLOG.md`

## References
- `references/README.md`
- `references/expected_sources.md`
- `references/naming_convention.md`

## Repo strategy
- `repo/repo_strategy.md`
