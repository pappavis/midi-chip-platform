# HANDOFF POLICY

## Doel
Handoffs voorkom dat werk tussen agents of tussen mens en AI vervaag.

## Elke handoff moet bevat
- wat ontvang is
- wat gedoen is
- wat uit scope gebly het
- wat onseker bly
- wat die volgende rol moet doen
- watter gate reeds deur is
- watter gate nog oop is

## Handoff formaat
### 1. Context
Kort opsomming van huidige stand

### 2. Input consumed
Watter bronne of artefakte gebruik is

### 3. Output produced
Watter nuwe artefakte of aanbevelings gemaak is

### 4. Risks / unknowns
Wat nog onseker of riskant is

### 5. Next action
Wie moet volgende doen, en waarmee

## Belangrike reël
Geen handoff mag 'n glanssamevatting wees wat die swak plekke wegsteek nie.
